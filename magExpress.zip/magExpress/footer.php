<footer id="footer">
  <div class="footer_top">
    <div class="container">
      <div class="row">
		<?php dynamic_sidebar('fs');?> 
      </div>
    </div>
  </div>
  <div class="footer_bottom">
    <div class="container">
      <div class="row">
		<?php dynamic_sidebar('fs-1');?> 
      </div>
    </div>
  </div>
</footer>
<?php wp_footer();?>
</body>
</html>