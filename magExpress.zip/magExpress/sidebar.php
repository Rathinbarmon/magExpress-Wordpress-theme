 <?php dynamic_sidebar('rs');?>
 