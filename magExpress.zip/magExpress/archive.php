<?php get_header();?>
  <section id="mainContent">
    <div class="content_bottom">
      <div class="col-lg-8 col-md-8">
        <div class="content_bottom_left">
          <div class="single_page_area">
            <ol class="breadcrumb">
              <li><a href="<?php bloginfo('home');?>">Home</a></li>
              <li><a href="#"><?php the_title();?></a></li>
            </ol>
			<h1>
					<?php
					if(is_category()){
						single_cat_title();
					}
					elseif(is_tag()){
						single_tag_title();
					}
					elseif(is_author()){
						echo'Author Archives: '.get_the_author();
						rewind_posts();
					}
					elseif(is_day()){
						echo' Daily Archives: '.get_the_date();
					}
					elseif(is_month()){
						echo' Monthly Archives: '.get_the_date('F Y');
					}
					elseif(is_year()){
						echo' Yearly Archives: '.get_the_date('Y');
					}
					else{
						echo'This ';
					}
					?>
				</h1>
			<?php while(have_posts()):the_post();?>
            <h2 class="post_titile"><?php the_title();?></h2>
            <div class="single_page_content">
              <div class="post_commentbox"> <a href="<?php the_permalink();?>"><i class="fa fa-user"></i><?php the_author();?></a>
					<span><i class="fa fa-calendar"></i><?php the_date('F j, Y');?></span>
					<a href="#"><i class="fa fa-tags"></i><?php the_tags();?></a> 
			  </div>
					<?php  the_post_thumbnail(
					'full',array(
					'class'=>'img-center'
					));?> 
					
					<?php the_content();?> 
            </div>
			<?php endwhile;?>
          </div>
        </div>
        <div class="pagination_area">
          <nav>
		    <?php the_posts_pagination( array(
					'prev_text'          => __( '<<', 'magexpress' ),
					'next_text'          => __( '>>', 'magexpress' ),
					'screen_reader_text'          => __( ' ', 'magexpress' ),
			));?>  
          </nav>
        </div>
        <div class="share_post"> 
			<a class="facebook" href="#"><i class="fa fa-facebook"></i>Facebook</a> 
			<a class="twitter" href="#"><i class="fa fa-twitter"></i>Twitter</a> 
			<a class="googleplus" href="#"><i class="fa fa-google-plus"></i>Google+</a>
			<a class="linkedin" href="#"><i class="fa fa-linkedin"></i>LinkedIn</a> 
			<a class="stumbleupon" href="#"><i class="fa fa-stumbleupon"></i>StumbleUpon</a>
			<a class="pinterest" href="#"><i class="fa fa-pinterest"></i>Pinterest</a>
		</div>
        
    </div>
	<div class="col-lg-4 col-md-4">
    <?php get_sidebar();?>   
    </div>
  </section>
</div>

<?php get_footer();?>