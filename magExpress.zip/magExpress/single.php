<?php get_header();?>
  <section id="mainContent">
    <div class="content_bottom">
      <div class="col-lg-8 col-md-8">
        <div class="content_bottom_left">
          <div class="single_page_area">
            <ol class="breadcrumb">
              <li><a href="<?php bloginfo('home');?>">Home</a></li>
              <li><a href="#"><?php the_title();?></a></li>
            </ol>
			<?php
				$sp= new WP_query( array(
				'post_type'=>'post',
				'posts_per_page'=>1, 
			))?>
			<?php while(have_posts()):the_post();?>
            <h2 class="post_titile"><?php the_title();?></h2>
            <div class="single_page_content">
              <div class="post_commentbox"> <a href="<?php the_permalink();?>"><i class="fa fa-user"></i><?php the_author();?></a>
					<span><i class="fa fa-calendar"></i> <?php the_date('F j, Y');?> </span>
					<a href="#"><i class="fa fa-tags"></i><?php the_tags();?></a> 
			  </div>
					<?php  the_post_thumbnail(
					'full',array(
					'class'=>'img-center'
					));?> 
					
					<?php the_content();?>
					<?php comments_template();?>
            </div>
			<?php endwhile;?>
			
          </div>
        </div>
        <div class="post_pagination">
			<div class="prev">
				<a class="angle_left" href="#">
					<i class="fa fa-angle-double-left"></i>
				</a>
				<div class="pagincontent"> <span>Previous Post</span> 
					<?php previous_post_link();?> 
				</div>
			</div>
			<div class="next">
				<div class="pagincontent"> 
					<span>Next Post</span>
					 <?php next_post_link();?> 
				</div>
				<a class="angle_right">
					 <i class="fa fa-angle-double-right"></i>
				</a>  
			</div>
        </div>
        <div class="share_post"> 
			<a class="facebook" href="https://www.facebook.com/rdr/<?php the_permalink();?>"><i class="fa fa-facebook"></i>Facebook</a> 
			<a class="twitter" href="https://www.twitter.com/rdr/<?php the_permalink();?>"> <i class="fa fa-twitter"></i> Twitter</a> 
			<a class="googleplus" href="https://www.googleplus.com/rdr/<?php the_permalink();?>"><i class="fa fa-google-plus"></i>Google+</a>
			<a class="linkedin" href="#"><i class="fa fa-linkedin"></i>LinkedIn</a> 
			<a class="stumbleupon" href="#"><i class="fa fa-stumbleupon"></i>StumbleUpon</a>
			<a class="pinterest" href="#"><i class="fa fa-pinterest"></i>Pinterest</a>
		</div>
				 
        <div class="similar_post"> 
          <h2>Similar Post You May Like <i class="fa fa-thumbs-o-up"></i></h2>
          <ul class="small_catg similar_nav wow fadeInDown animated">

		  
					<?php 
					$related = get_posts( array(
						'category__in' => wp_get_post_categories($post->ID),
						'posts_per_page' =>3, 
						'post__not_in' => array($post->ID) 
					) );?>
					
					
					<?php if( $related ) foreach( $related as $post ) {
					setup_postdata($post); ?>
					   
						<li>
							<div class="media wow fadeInDown animated" style="visibility: visible; animation-name: fadeInDown;">  
								<div class="media-body">
									<h4 class="media-heading"><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_title(); ?></a></h4>
									<a class="media-left related-img"  >
										<?php  the_post_thumbnail();?> 
									</a>
									<?php the_excerpt();?>
								</div>
							</div>
						</li>
					    
					<?php }
					wp_reset_postdata(); ?>
					
					
			 
             
             
          </ul>
        </div>
    </div>
	<div class="col-lg-4 col-md-4">
    <?php get_sidebar();?>   
    </div>
  </section>
</div>

<?php get_footer();?>