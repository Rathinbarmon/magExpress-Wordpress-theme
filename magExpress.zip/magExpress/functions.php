<?php 

//After theme set up

function magexpress_setup(){
	
	load_theme_textdomain( 'magexpress', get_template_directory() . '/languages/' );
	add_theme_support( 'title-tag' );
	add_theme_support( 'custom-background' );
	add_theme_support( 'post-thumbnails' ); 
    add_image_size('about',300,300,true);
	
	register_nav_menus( array(
		'primary' => __( 'Header Menu', 'magexpress' ), 
	));
	register_nav_menus( array(
		'main' => __( 'Main Menu', 'magexpress' ), 
	));
	require_once('menu/menu.php'); 
	
	add_theme_support( 'post-formats', array(
		'aside', 'image','audio','video', 'quote', 'link', 'gallery', 'status',  'chat'
	) );
}
add_action( 'after_setup_theme', 'magexpress_setup' );

// Default menu setup
 
function default_menu(){
	
	echo'<ul>';
	if(is_user_logged_in()){
		echo'<li><a href="'.home_url().'/wp-admin/nav-menus.php"> Create Your Main Menu!!! </a></li>';
	}
	else{ 
		echo'<li><a href="'.home_url().'"> Home </a></li>';
	}
	echo'</ul>';
}

function default_menu_haeder(){
	
	echo'<ul>';
	if(is_user_logged_in()){
		echo'<li><a href="'.home_url().'/wp-admin/nav-menus.php"> Create Header Your Menu </a></li>';
	}
	else{ 
		echo'<li><a href="'.home_url().'"> Home </a></li>';
	}
	echo'</ul>';
}

/* /custom post register
function magexpress_custom_post(){ 

	register_post_type('logo',array(
	   'labels'=>array(
			'name'=>__('Upload Logo','magexpress')
	   ),  
	   'supports'=>array('thumbnail'),
	   'public'=>true,	   
	));
	
	register_post_type('cp',array(
	   'labels'=>array(
			'name'=>__('Copyright Text','magexpress')
	   ),  
	   'supports'=>array('title','editor'),
	   'public'=>true,	
	));
}
add_action( 'init', 'magexpress_custom_post' );
*/

function magexpress_style_script(){
    //style sheet adding function
 	wp_register_style( 'bootstrap', get_template_directory_uri() . '/assets/css/bootstrap.min.css' );
 	wp_register_style( 'awesome', get_template_directory_uri() . '/assets/css/font-awesome.min.css' );
 	wp_register_style( 'animate', get_template_directory_uri() . '/assets/css/animate.css' );
 	wp_register_style( 'slick', get_template_directory_uri() . '/assets/css/slick.css' ); 
 	wp_register_style( 'theme', get_template_directory_uri() . '/assets/css/theme.css');
 	wp_register_style( 'style', get_template_directory_uri() . '/assets/css/style.css');
 	 
	wp_enqueue_style( 'bootstrap');
	wp_enqueue_style( 'awesome');
	wp_enqueue_style( 'animate');
	wp_enqueue_style( 'slick');
	wp_enqueue_style( 'theme');
	wp_enqueue_style( 'style');
	//js adding function
 	wp_register_script( 'main', get_template_directory_uri() . '/assets/js/jquery.min.js');
 	wp_register_script( 'bootstrap', get_template_directory_uri() . '/assets/js/bootstrap.min.js');
 	wp_register_script( 'wow', get_template_directory_uri() . '/assets/js/wow.min.js');
 	wp_register_script( 'slick', get_template_directory_uri() . '/assets/js/slick.min.js');
 	wp_register_script( 'custom', get_template_directory_uri() . '/assets/js/custom.js');
   
   wp_enqueue_script('main');
   wp_enqueue_script('bootstrap');
   wp_enqueue_script('wow');
   wp_enqueue_script('slick');
   wp_enqueue_script('custom');
    
}
add_action('wp_enqueue_scripts','magexpress_style_script'); 

//widget register

function magexpress_widget(){
register_sidebar( array(
		'name'          => __( 'sidebar Widget Area', 'magexpress' ),
		'id'            => 'rs',
		'description'   => __( 'Appears in the footer section of the site.', 'magexpress' ),
		'before_widget' => '<div class="content_bottom_right"><div class="single_bottom_rightbar">',
		'after_widget'  => '</div></div>',
		'before_title'  => '<h2>',
		'after_title'   => '</h2> ',
	) );
	
register_sidebar( array(
		'name'          => __( 'Footer sidebar Widget Area', 'magexpress' ),
		'id'            => 'fs',
		'description'   => __( 'Appears in the footer section of the site.', 'magexpress' ),
		'before_widget' => '<div class="col-lg-4 col-md-4 col-sm-4"><div class="single_footer_top wow fadeInLeft">',
		'after_widget'  => '</div></div>',
		'before_title'  => '<h2>',
		'after_title'   => '</h2>',
	) );
	register_sidebar( array(
		'name'          => __( 'Footer Copyright Widget Area', 'magexpress' ),
		'id'            => 'fs-1',
		'description'   => __( 'Appears in the footer section of the site.', 'magexpress' ),
		'before_widget' => '<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12"><div class="footer_bottom_left">',
		'after_widget'  => '</div></div>',
		'before_title'  => '<h2 style="display:none">',
		'after_title'   => '</h2>',
	) );
}
add_action( 'widgets_init', 'magexpress_widget' );   
?>