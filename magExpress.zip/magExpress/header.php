<?php
/**
 * The template for displaying the header
 *
 * Displays all of the content.
 *
 * @package WordPress
 * @subpackage magExpress
 * @since  magExpress 1.0.0
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head> 
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head();?>
</head>
<body <?php body_class();?>>
<div id="preloader">
  <div id="status">&nbsp;</div>
</div>
<a class="scrollToTop" href="#"><i class="fa fa-angle-up"></i></a>
<div class="container">
  <header id="header">
    <div class="row">
      <div class="col-lg-12 col-md-12">
        <div class="header_top">
			<div class="header_top_left"> 
				<?php
					wp_nav_menu(array(
						'theme_location'=>'primary',
						'menu_class'=>'top_nav',
						'container'=>'',
						'fallback_cb'=>'default_menu_haeder',
						'walker'=>new wp_bootstrap_navwalker()
					));
				?>  
			</div>
          <div class="header_top_right">
            <form action=" " class="search_form">
              <input type="text" name="s"placeholder="Text to Search">
              <input type="submit" value=" ">
            </form>
          </div>
        </div>
        <div class="header_bottom">
          <div class="header_bottom_left"><a class="logo" href="<?php bloginfo('home');?>"><strong><?php bloginfo('title');?></strong> <span><?php bloginfo('description');?></span></a></div>
        </div>
      </div>
    </div>
  </header>
  <div id="navarea">
    <nav class="navbar navbar-default" role="navigation">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
			<?php
				wp_nav_menu(array(
					'theme_location'=>'main',
					'menu_class'=>'nav navbar-nav custom_nav',
					'container'=>'',
					'fallback_cb'=>'default_menu',
					'walker'=>new wp_bootstrap_navwalker()
				));
			?> 
        </div>
      </div>
    </nav>
  </div>