<?php get_header();?>
  <section id="mainContent">
    <div class="content_middle">
      <div class="col-lg-3 col-md-3 col-sm-3">
        <div class="content_middle_leftbar">
          <div class="single_category wow fadeInDown">
            <h2> <span class="bold_line"><span></span></span> <span class="solid_line"></span> <a href="archive1.html" class="title_text">category1</a> </h2>
            
			<?php $cat1= new WP_query(array(
				'post_type'=>'post',
				'posts_per_page'=>2,
				'category_name'=>'category1'
			)); ?> 
			<ul class="catg1_nav">
			<?php if(have_posts()):?>
				<?php while($cat1->have_posts()):$cat1->the_post();?>
                <li>
                <div class="catgimg_container"> 
					<a href="<?php the_permalink();?>" class="catg1_img"> 
					<?php the_post_thumbnail();?> 
					</a> 
				</div>
                <h3 class="post_titile"><a href="<?php the_permalink();?>"><?php the_title();?></a></h3>
                </li> 
			    <?php endwhile; 
			          else: 
					  echo'No Found in category 1'; 
			endif;?>
            </ul>			
          </div>
        </div>
      </div>
      <div class="col-lg-6 col-md-6 col-sm-6">
        <div class="content_middle_middle">
			<div class="slick_slider2">
				<?php $cat2= new WP_query(array(
					'post_type'=>'post',
					'posts_per_page'=>5, 
				));?>
				<?php if(have_posts()):?>
					<?php while($cat2->have_posts()):$cat2->the_post();?>
					<div class="single_featured_slide">
					<a href="<?php the_permalink();?>">
					<?php the_post_thumbnail();?>
					</a>
					  <h2><a href="<?php the_permalink();?>"><?php the_title();?></a></h2>
					  <p><?php the_excerpt();?></p>
					</div>
					<?php endwhile; 
			          else: 
					  echo'No Found in slider'; 
				endif;?>
			</div>
        </div>
      </div>
      <div class="col-lg-3 col-md-3 col-sm-3">
        <div class="content_middle_rightbar">
          <div class="single_category wow fadeInDown">
            <h2> <span class="bold_line"><span></span></span> <span class="solid_line"></span> <a href="archive1.html" class="title_text">category2</a> </h2>
            <?php $cat3= new WP_query(array(
				'post_type'=>'post',
				'posts_per_page'=>2,
				'category_name'=>'category3'
			)); ?> 
			<ul class="catg1_nav">
			  <?php if(have_posts()):?>
			  <?php while($cat3->have_posts()):$cat3->the_post();?>
				  <li>
					<div class="catgimg_container"> 
						<a href="<?php the_permalink();?>" class="catg1_img"> 
						<?php the_post_thumbnail();?> 
						</a> 
					</div>
					<h3 class="post_titile"><a href="<?php the_permalink();?>"><?php the_title();?></a></h3>
				  </li> 
					<?php endwhile; 
			          else: /*get_template_part();*/
					  echo'No post Found'; 
				endif;?>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <div class="content_bottom">
      <div class="col-lg-8 col-md-8">
        <div class="content_bottom_left">
          <div class="single_category wow fadeInDown">
            <div class="archive_style_1">
              <h2><span class="bold_line"><span></span></span> <span class="solid_line"></span> <span class="title_text">Post Updates</span> </h2>
				
				<?php while(have_posts()):the_post();?>
				<div class="single_archive wow fadeInDown">
					<div class="archive_imgcontainer"><?php the_post_thumbnail();?> </div>
					<div class="archive_caption">
					  <h2><a href="<?php the_permalink();?>"><?php the_title();?></a></h2>
					  <?php the_excerpt();?>
					</div>
					<a class="read_more" href="<?php the_permalink();?>"><span>Read More</span></a> 
				</div>
				<?php endwhile;?>	
				
            </div>
          </div>
        </div>
        <div class="pagination_area">
          <nav>
		    <?php the_posts_pagination( array(
					'prev_text'          => __( '<<', 'magexpress' ),
					'next_text'          => __( '>>', 'magexpress' ),
					'screen_reader_text'          => __( ' ', 'magexpress' ),
					'mid_size'  =>10,
			));?>  
          </nav>
        </div>
      </div>
        <div class="col-lg-4 col-md-4">
        <?php get_sidebar();?> 
		</div>		
  </section>
</div>
<?php get_footer();?>