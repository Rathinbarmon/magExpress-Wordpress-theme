<?php get_header();?>
  <section id="mainContent">
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12">
        <div class="error_page_content">
          <h1>404</h1>
          <h2>Sorry :(</h2>
          <h3>This Page Doesn't Found.</h3>
          <p class="wow fadeInLeftBig">Please, continue to our <a href="<?php bloginfo('home');?>">Home page</a></p>
				<?php wp_list_pages( array(
					'before'         => '<h3>',
					'after'          => '</h3>', 
				));?>  
        </div>
      </div>
    </div>
  </section>
</div>
<?php get_footer();?>