<?php
/*
 * The template for displaying search results pages.
 * @package WordPress
 *  @subpackage magExpress
 * @since  magExpress 1.0.0
 */
 ?>

<?php get_header();?>
  <section id="mainContent"> 
    <div class="content_bottom">
      <div class="col-lg-8 col-md-8">
        <div class="content_bottom_left">
          <div class="single_category wow fadeInDown">
            <div class="archive_style_1">
              <h2>
					<span class="bold_line">
					<span></span>
					</span>
					<span class="solid_line"></span>
					<span class="title_text">
					You are Search : <?php echo get_search_query();?> 
					</span>
			  </h2>
			  <?php if(have_posts()):?>
				<?php while(have_posts()):the_post();?>
				<div class="single_archive wow fadeInDown">
					<div class="archive_imgcontainer"><?php the_post_thumbnail();?> </div>
					<div class="archive_caption">
					  <h2><a href="<?php the_permalink();?>"><?php the_title();?></a></h2>
					  <?php the_excerpt();?>
					</div>
 				</div>
				<?php endwhile;?>
			    <?php else: echo'Not Found';?>
				<?php endif;?>
            </div>
          </div>
        </div>
        <div class="pagination_area">
          <nav>
		    <?php the_posts_pagination( array(
					'prev_text'          => __( '<<', 'magexpress' ),
					'next_text'          => __( '>>', 'magexpress' ),
					'screen_reader_text'          => __( ' ', 'magexpress' ),
			));?>  
          </nav>
        </div>
      </div>
        <div class="col-lg-4 col-md-4">
        <?php get_sidebar();?> 
		</div>		
	</section>
</div>
<?php get_footer();?>