<?php
/*
Template Name:Page Maker
*/
 get_header();?>
  <section id="mainContent">
    <div class="content_bottom">
	
    </div>  
  </section>
</div>

<?php get_footer();?>